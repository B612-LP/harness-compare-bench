# BIRD 1.2-q26-frpm 候选交付

状态 **candidate-not-adopted**，不是覆盖现行1.1。case_id仍为bird-ca-schools-15，旧答案格式兼容；只有q26的gold由Free Meal改为FRPM，并明确本地5–17岁、严格>800。原英文15–17保留且标差异，不宣称15题gold仍全为官方原样。**q27及其余14题gold、question对象均不改**；q27的raw-key LEFT、NULL、重复投影继续冻结，前导0/人口合同局限不在本轮擅改。

## 入口

- [完整独立候选case](<candidate-1.2-q26-frpm/>)：真实数据库和全部输入副本，无symlink；直接运行其[checker.py](<candidate-1.2-q26-frpm/checker.py>)即可。候选[spec](<candidate-1.2-q26-frpm/spec.md>)、[instruction](<candidate-1.2-q26-frpm/instruction.md>)、[truth](<candidate-1.2-q26-frpm/truth.json>)、[solution](<candidate-1.2-q26-frpm/solution/answers.jsonl>)、[case](<candidate-1.2-q26-frpm/case.json>)、[task](<candidate-1.2-q26-frpm/task.toml>)同步。task顶部version=1.0是任务schema，保持不变；metadata checker_version才是候选版本。
- [旧1.1完整快照](<baseline-1.1/>)：源仓a2234fc只读复制，保留旧版本和旧输入。
- [build_replay.py](<build_replay.py>)：构建+真实新旧自测+oracle交叉+边界+8场回放。已有候选不会默认覆盖：重新生成至自有校验暂存区，逐文件比对一致才继续，不一致则拒绝覆盖。
- [audit.json](<audit.json>)：完整CLI结果、输入迁移说明、源码/历史答案/CHANGELOG/既有复算结果前后hash、候选文件hash。
- [旧自测](<old-1.1.selftest.txt>) **21/21**、[新自测](<candidate.selftest.txt>) **25/25**，均exit0。

```bash
# 从交付包根目录执行；构建/八场回放需原仓a2234fc，后两条仅需本包
python3 -B bird-q26/build_replay.py --repo /path/to/harness-compare-bench
python3 -B bird-q26/candidate-1.2-q26-frpm/checker.py --selftest
python3 -B bird-q26/candidate-1.2-q26-frpm/checker.py RUN_DIR --json
```

第一条要求源仓revision为a2234fc。脚本只写本交付目录，构建、回放、所有selftest临时目录均在本目录下；无模型/网络/GUI。完整候选case本身可脱离原仓独立判卷，构建与历史答案回放才需要原仓来源。

## 红绿收据

1. 原1.1 selftest21/21，新候选25/25；新4项分别q26旧Free5行、漏North一校、附加一校、重复一校，均q26失败但其余14题全对，因此**整场14/15、reward1**，不错误增加单题硬否决。
2. 新oracle在新checker **15/15**；旧oracle在新checker **14/15**；新oracle在旧checker **14/15**。三者均reward1/exit0，只有q26变化。
3. 799/800/801合成CTE验证严格>800仅保留801、>=800还保留800。实际本县公立高中没有FRPM恰800记录，故明确不把真实库上>与>=等价冒称边界验证。
4. 8场历史答案在新旧两版CLI真实回放。每版运行目录都临时复制**对应版本canonical inputs**，因此input_integrity均verified；不是把旧questions硬塞新版造成hash误拒。答案文件原样，不改原现场。

| 旧提交 | 旧1.1参考 | 候选回放 | reward旧→新 |
|---|---:|---:|---|
| Codex首跑 | 13/15，86.67 | 14/15，93.33 | 1→1 |
| DSH首跑 | 13/15，86.67 | 14/15，93.33 | 1→1 |
| WorkBuddy首跑 | 13/15，86.67 | 14/15，93.33 | 1→1 |
| 豆包首跑 | 9/15，60.00 | 10/15，66.67 | 0→0 |
| Codex重复2 | 13/15，86.67 | 14/15，93.33 | 1→1 |
| Codex重复3 | 12/15，80.00 | 13/15，86.67 | 1→1 |
| DSH重复2 | 13/15，86.67 | 14/15，93.33 | 1→1 |
| DSH重复3 | 13/15，86.67 | 14/15，93.33 | 1→1 |

所有8场均只改变q26逐题命中，q27和其余题命中不变。**这些是旧答案对新合同的迁移回放，不是模型在新题面下当时获得的成绩，不覆盖历史元数据，不算新增独立运行。** 源仓、CHANGELOG、原checker/gold/已有results/历史产物保护hash前后未变；未提交git、未触碰G2R4。
