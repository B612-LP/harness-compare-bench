# BIRD 1.2-q26-frpm 候选合同（非默认1.1）

case_id仍为bird-ca-schools-15，checker/truth/task metadata/case版本1.2-q26-frpm；状态candidate-not-adopted。task.toml顶部version=1.0仍为任务schema，不改为checker版本。
仅q26 gold的Free Meal Count (Ages 5-17)改为FRPM Count (Ages 5-17)，满足中文“免费或减价餐”。
严格>800，800不满足；本地年龄明确5-17，原英文15-17是历史题源差异，不宣称原样题面或gold全集。
q26按School Name、Street、City、State、Zip输出；县Monterey、公立高中筛选不变。
数据库/schema/sample不改，questions仅q26 evidence/source说明改，truth输入SHA/字节同步更新；solution仅q26改。
其余14题gold逐字不变。q27继续原raw-key LEFT，保留无SAT和NULL、重复投影行；前导0/人口口径歧义未在本轮修复。

答案必须15个id齐全、无重复/额外/非法非空行；schema/coverage/输入完整性都是硬门。
exec-accuracy≥0.8（12/15）通过，weighted=accuracy×100。单题错误只丢该题，不强制整场0。
结果行多重集比较，列序敏感、行序无关；NULL→<NULL>，float round6，字符串strip，重复行敏感。
启动truth版本/阈值/题集/输入SHA守卫及gold可执行非空守卫均保留。仅标准库、无网络、无LLM judge。

运行：python3 checker.py RUN_DIR --json；python3 checker.py --selftest。exit0=通过、1=未过、2=用例/自测错误。
内置自测25项：原1.1的21项及q26旧Free5行/漏一校/附一校/重复一校4项；这些q26负例均14/15且整场仍过。
独立build_replay.py另验证799/800/801严格边界（实际库筛选无恰800，不能把>=800在本库等价当证据）、新旧oracle交叉和8场历史答案回放。
回放在外部临时运行目录用旧答案+新版inputs，不是在新题面下新跑模型，不覆盖历史meta/results。
来源BIRD mini_dev，CC BY-SA4.0，原始读取2026-10-22。仅q26为本地合同gold修订，非官方评分版本。
