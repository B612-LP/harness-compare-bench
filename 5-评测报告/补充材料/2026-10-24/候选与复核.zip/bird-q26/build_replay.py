#!/usr/bin/env python3
"""Build standalone candidate, test real old/new CLIs, replay 8 historical answers. No model calls."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile

OUT = Path(__file__).resolve().parent
VERSION = '1.2-q26-frpm'
FILES = ('checker.py','truth.json','spec.md','instruction.md','task.toml','case.json',
         'solution/answers.jsonl','inputs/questions.json','inputs/schema.sql',
         'inputs/sample_rows.json','inputs/db/california_schools.sqlite')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def dump(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path('/Users/b612-lp/Documents/harness-compare-bench'))
    args=parser.parse_args(); repo=args.repo.resolve(); source=repo/'2-用例/bird-ca-schools-15'
    assert not OUT.is_relative_to(repo)
    revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    assert revision.startswith('a2234fc'), revision
    selected=json.loads((repo/'5-评测报告/复算/2026-10-24/results.json').read_text())
    runs=[r for r in selected['runs'] if r['task']=='bird-ca-schools-15']; assert len(runs)==8
    artifacts={}
    for r in runs:
        base=repo/r['source']
        candidates=[base/'answers.jsonl',base/'workspace/answers.jsonl']
        available=[p for p in candidates if p.is_file()]; assert len(available)==1
        artifacts[r['run_id']]=available[0]
    protected=[source/f for f in FILES]+list(artifacts.values())+[repo/'5-评测报告/复算/2026-10-24/results.json',repo/'CHANGELOG.md']
    before={str(p.relative_to(repo)):sha(p) for p in protected}
    baseline=OUT/'baseline-1.1'; final_candidate=OUT/'candidate-1.2-q26-frpm'
    candidate=OUT/'build-verification' if final_candidate.exists() else final_candidate
    for directory in (baseline,candidate):
        for rel in FILES:
            p=directory/rel; p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes((source/rel).read_bytes())
    truth=json.loads((candidate/'truth.json').read_text()); oldtruth=json.loads((baseline/'truth.json').read_text())
    oldsql=truth['answers']['26']['sql']; newsql=oldsql.replace('Free Meal Count (Ages 5-17)','FRPM Count (Ages 5-17)')
    assert oldsql!=newsql
    truth['checker_version']=VERSION
    truth['contract_status']='candidate-not-adopted'
    truth['parent_checker_version']='1.1'
    truth['changed_questions']=['26']
    truth['answers']['26']['sql']=newsql
    truth['source']['gold_sql_unmodified']=False
    truth['source']['modified_gold_question_ids']=[26]
    truth['source']['modification']='候选1.2-q26-frpm：仅q26将Free Meal Count改为FRPM Count，中文明确本地5-17岁及严格>800；原英文15-17保留为来源差异。其余14题gold和数据库不变；非官方原样gold全集。'
    truth['source']['parent_repository_commit']=revision
    questions=json.loads((candidate/'inputs/questions.json').read_text())
    for q in questions:
        if q['question_id']==26:
            q['evidence_zh']='免费或减价餐人数使用 frpm.`FRPM Count (Ages 5-17)`，不是 Free Meal Count；严格 >800（800不满足）。本地合同年龄为5-17岁，原英文15-17仅为历史题源原文。完整通讯地址按Street、City、State、Zip输出。'
            q['source_note']+=' 候选1.2-q26-frpm明确本地5-17/FRPM口径，并据此改写q26 gold；原英文15-17不作为本地年龄要求。'
    dump(candidate/'inputs/questions.json',questions)
    for rel in truth['input_sha256']:
        truth['input_sha256'][rel]=sha(candidate/rel)
        truth['input_bytes'][rel]=(candidate/rel).stat().st_size
    dump(candidate/'truth.json',truth)
    sol=[json.loads(line) for line in (candidate/'solution/answers.jsonl').read_text().splitlines()]
    for row in sol:
        if row['question_id']==26: row['sql']=newsql
    (candidate/'solution/answers.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in sol))
    checker=(candidate/'checker.py').read_text()
    checker=checker.replace('判分器 v1.1（2026-10-24，BIRD exec-accuracy + schema 硬门）','判分器 v1.2-q26-frpm（2026-10-24，候选：仅q26 FRPM合同修订）')
    checker=checker.replace('CHECKER_VERSION = "1.1"','CHECKER_VERSION = "1.2-q26-frpm"')
    checker=checker.replace('gold SQL 保持官方原样。','仅q26 gold改写为FRPM；其余14题gold保留官方原样。')
    checker=checker.replace('"checker_version": CHECKER_VERSION,','"checker_version": CHECKER_VERSION,\n        "contract_status": "candidate-not-adopted",\n        "parent_checker_version": "1.1",')
    extra='''    fixtures.append(("q26旧Free5行（逐题拒绝，14/15仍过）", 1,
                     _answers_text(variant(oracle_pairs, {"26": gold_sql["26"].replace("FRPM Count (Ages 5-17)", "Free Meal Count (Ages 5-17)")})),
                     "link", ("q26",), ("answers_schema", "answers_coverage")))
    fixtures.append(("q26漏North一校（逐题拒绝，14/15仍过）", 1,
                     _answers_text(variant(oracle_pairs, {"26": gold_sql["26"] + " AND T1.CDSCode != '27738252730034'"})),
                     "link", ("q26",), ("answers_coverage",)))
    fixtures.append(("q26附加一校（逐题拒绝，14/15仍过）", 1,
                     _answers_text(variant(oracle_pairs, {"26": gold_sql["26"] + " UNION ALL SELECT 'extra', 'street', 'city', 'CA', 'zip'"})),
                     "link", ("q26",), ("answers_coverage",)))
    fixtures.append(("q26重复一校（多重集拒绝，14/15仍过）", 1,
                     _answers_text(variant(oracle_pairs, {"26": gold_sql["26"] + " UNION ALL SELECT * FROM (" + gold_sql["26"] + " LIMIT 1)"})),
                     "link", ("q26",), ("answers_coverage",)))
'''
    marker='    print("[%s] checker v%s 自测（%d 题：challenging 5 / moderate 7 / simple 3；"'
    assert marker in checker; checker=checker.replace(marker,extra+'\n'+marker)
    (candidate/'checker.py').write_text(checker)
    instruction=(candidate/'instruction.md').read_text()
    instruction=instruction.replace('# bird-ca-schools-15：加州学校库 Text-to-SQL 15 题','# bird-ca-schools-15 · 1.2-q26-frpm 候选（非默认1.1）\n\n仅q26合同修订：免费或减价餐使用FRPM Count (Ages 5-17)，严格>800；不是Free Meal，800不满足。本地年龄5-17，英文15-17仅保留溯源。q27及其他14题不改；q27仍冻结raw-key LEFT/NULL/重复行政策，未声称业务歧义已解决。')
    instruction=instruction.replace('与官方 gold SQL','与当前版本合同 gold SQL')
    instruction=instruction.replace('15 题 gold SQL 保持官方原样','仅q26 gold改写Free Meal→FRPM；其余14题gold保持官方原样')
    (candidate/'instruction.md').write_text(instruction)
    task=(candidate/'task.toml').read_text()  # top-level version=1.0 is task schema, not checker version
    task=task.replace('[metadata]','[metadata]\nchecker_version = "1.2-q26-frpm"\ncontract_status = "candidate-not-adopted"\nparent_checker_version = "1.1"')
    (candidate/'task.toml').write_text(task)
    case=json.loads((candidate/'case.json').read_text()); case.update(case_id='bird-ca-schools-15',case_version=VERSION,checker_version=VERSION,contract_status='candidate-not-adopted')
    dump(candidate/'case.json',case)
    (candidate/'spec.md').write_text('''# BIRD 1.2-q26-frpm 候选合同（非默认1.1）

case_id仍为bird-ca-schools-15，checker/truth/task metadata/case版本1.2-q26-frpm；状态candidate-not-adopted。task.toml顶部version=1.0仍为任务schema，不改为checker版本。
仅q26 gold的Free Meal Count (Ages 5-17)改为FRPM Count (Ages 5-17)，满足中文“免费或减价餐”。
严格>800，800不满足；本地年龄明确5-17，原英文15-17是历史题源差异，不宣称原样题面或gold全集。
q26按School Name、Street、City、State、Zip输出；县Monterey、公立高中筛选不变。
数据库/schema/sample不改，questions仅q26 evidence/source说明改，truth输入SHA/字节同步更新；solution仅q26改。
其余14题gold逐字不变。q27继续原raw-key LEFT，保留无SAT和NULL、重复投影行；前导0/人口口径歧义未在本轮修复。

答案必须15个id齐全、无重复/额外/非法非空行；schema/coverage/输入完整性都是硬门。
exec-accuracy≥0.8（12/15）通过，weighted=accuracy×100。单题错误只丢该题，不强制整场0。
结果行多重集比较，列序敏感、行序无关；NULL→<NULL>，float round6，字符串strip，重复行敏感。
启动truth版本/阈值/题集/输入SHA守卫及gold可执行非空守卫均保留。仅标准库、无网络、无LLM judge。

运行：python3 checker.py RUN_DIR --json；python3 checker.py --selftest。exit0=通过、1=未过、2=用例/自测错误。
内置自测25项：原1.1的21项及q26旧Free5行/漏一校/附一校/重复一校4项；这些q26负例均14/15且整场仍过。
独立build_replay.py另验证799/800/801严格边界（实际库筛选无恰800，不能把>=800在本库等价当证据）、新旧oracle交叉和8场历史答案回放。
回放在外部临时运行目录用旧答案+新版inputs，不是在新题面下新跑模型，不覆盖历史meta/results。
来源BIRD mini_dev，CC BY-SA4.0，原始读取2026-10-22。仅q26为本地合同gold修订，非官方评分版本。
''')
    if candidate != final_candidate:
        assert all((candidate/f).read_bytes()==(final_candidate/f).read_bytes() for f in FILES), 'existing candidate differs; refusing overwrite'
        assert candidate.resolve() == (OUT/'build-verification').resolve() and candidate.parent == OUT
        shutil.rmtree(candidate)  # verified exact self-owned staging path only; never remove final candidate
        candidate=final_candidate
    assert all(truth['answers'][q]==oldtruth['answers'][q] for q in truth['answers'] if q!='26')
    oldqs=json.loads((baseline/'inputs/questions.json').read_text())
    assert all(a==b for a,b in zip(oldqs,questions) if a['question_id']!=26)
    assert (baseline/'inputs/db/california_schools.sqlite').read_bytes()==(candidate/'inputs/db/california_schools.sqlite').read_bytes()
    tmpbase=OUT/'temporary';tmpbase.mkdir(exist_ok=True)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmpbase),TEMP=str(tmpbase),TMP=str(tmpbase))
    tests=[]
    def invoke(case, run=None, selftest=False):
        cmd=[sys.executable,str(case/'checker.py')]+(['--selftest'] if selftest else [str(run),'--json'])
        proc=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=180)
        return proc,cmd
    for label,directory in [('old-1.1',baseline),('candidate',candidate)]:
        proc,cmd=invoke(directory,selftest=True)
        (OUT/f'{label}.selftest.txt').write_text(proc.stdout+proc.stderr)
        assert proc.returncode==0,proc.stdout+proc.stderr
        tests.append({'id':label+'-selftest','command':cmd,'exit_code':proc.returncode,'stdout':proc.stdout})
    replay=[]
    with tempfile.TemporaryDirectory(prefix='replay-',dir=tmpbase) as tmp:
        temp=Path(tmp)
        for index,r in enumerate(runs):
            pair={}
            for label,directory in [('old-1.1',baseline),('candidate',candidate)]:
                work=temp/f'{index}-{label}';work.mkdir()
                shutil.copyfile(artifacts[r['run_id']],work/'answers.jsonl')
                shutil.copytree(directory/'inputs',work/'inputs')
                proc,cmd=invoke(directory,work)
                assert proc.returncode in (0,1),proc.stderr
                result=json.loads(proc.stdout)
                assert result['input_integrity']=='verified'
                pair[label]={'exit_code':proc.returncode,'command':cmd,'result':result}
            old=pair['old-1.1']['result'];new=pair['candidate']['result']
            assert old['weighted']==r['weighted'] and old['reward']==r['reward']
            assert new['correct']==old['correct']+1
            assert new['reward']==old['reward']
            assert [x['id'] for x,y in zip(old['checks'],new['checks']) if x['pass']!=y['pass']]==['q26']
            replay.append({'run_id':r['run_id'],'product':r['product'],'replicate':r['replicate'],
                           'kind':'historical-answer-replay-not-new-model-run','input_migration':'copy each version canonical inputs into isolated replay; original historical inputs untouched',**pair})
        for label,oracle_dir,judge_dir,correct in [('new-oracle-new',candidate,candidate,15),('old-oracle-new',baseline,candidate,14),('new-oracle-old',candidate,baseline,14)]:
            work=temp/label;work.mkdir();shutil.copyfile(oracle_dir/'solution/answers.jsonl',work/'answers.jsonl')
            proc,cmd=invoke(judge_dir,work);result=json.loads(proc.stdout)
            assert proc.returncode==0 and result['correct']==correct
            tests.append({'id':label,'exit_code':proc.returncode,'result':result})
    con=sqlite3.connect((candidate/'inputs/db/california_schools.sqlite').resolve().as_uri()+'?mode=ro',uri=True)
    con.execute('PRAGMA query_only=ON')
    strict=con.execute('WITH sample(n) AS (VALUES(799),(800),(801)) SELECT n FROM sample WHERE n>800').fetchall()
    inclusive=con.execute('WITH sample(n) AS (VALUES(799),(800),(801)) SELECT n FROM sample WHERE n>=800').fetchall()
    assert strict==[(801,)] and inclusive==[(800,),(801,)] and '> 800' in newsql
    real800=con.execute("SELECT COUNT(*) FROM frpm f JOIN schools s USING(CDSCode) WHERE s.County='Monterey' AND f.`School Type`='High Schools (Public)' AND f.`FRPM Count (Ages 5-17)`=800").fetchone()[0]
    con.close();tests.append({'id':'synthetic-800-boundary','strict_gt800':strict,'inclusive_ge800':inclusive,'actual_scope_equal800_count':real800,'pass':True})
    after={str(p.relative_to(repo)):sha(p) for p in protected};assert before==after
    payload={'candidate_version':VERSION,'candidate_status':'candidate-not-adopted','case_id':'bird-ca-schools-15',
             'source_repository_commit':revision,'new_agent_runs':0,'formal_historical_results_overwritten':False,
             'source_hashes_before':before,'source_hashes_after':after,'protected_unchanged':before==after,
             'candidate_hashes':{rel:sha(candidate/rel) for rel in FILES},'only_gold_q26_changed':True,
             'q27_unchanged_and_semantic_limitations_retained':True,'tests':tests,'historical_replays':replay}
    dump(OUT/'audit.json',payload)
    print('Old selftest21/21; candidate25/25; oracle cross-tests3/3; synthetic800 boundary pass; eight old/new replays all verified, onlyq26 +1; source protection hashes unchanged')
    for r in replay:
        a=r['old-1.1']['result'];b=r['candidate']['result'];print(r['product'],r['replicate'],a['correct'],a['weighted'],'->',b['correct'],b['weighted'],'reward',a['reward'],b['reward'])
    return 0

if __name__=='__main__':
    raise SystemExit(main())
