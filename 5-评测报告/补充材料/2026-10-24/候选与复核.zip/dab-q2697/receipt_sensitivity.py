#!/usr/bin/env python3
"""Receipt-derived sensitivity ONLY: no business gold validation or model runs."""
import argparse
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--results',type=Path,default=HERE/'receipt-source.json');args=ap.parse_args()
 data=json.loads(args.results.read_text());rows=[];frozen=[]
 for r in data['runs']:
  if r['task']!='dabstep-payments-10':continue
  item={'product':r['product'],'replicate':r['replicate'],'source':r['source'],'modes':{}}
  keep={'product':r['product'],'replicate':r['replicate'],'source':r['source'],'task':r['task'],'strict':{}}
  for mode in ('official_compat','strict_contract'):
   score=r['strict'][mode];q=next(c for c in score['checks'] if c.get('task_id')=='2697')
   c9=score['correct']-int(q['pass'])
   item['modes'][mode]={'frozen10':{'correct':score['correct'],'weighted':score['weighted'],'reward':score['reward']},'q2697_pass':q['pass'],'q2697_note':q['note'],'exclude2697_9':{'correct':c9,'weighted':round(c9/9*100,2),'reward':int(c9/9>=0.8)},'headline_changed':score['reward']!=int(c9/9>=0.8)}
   keep['strict'][mode]={'correct':score['correct'],'weighted':score['weighted'],'reward':score['reward'],'checks':[q]}
  rows.append(item);frozen.append(keep)
 assert len(rows)==8
 (HERE/'receipt-source.json').write_text(json.dumps({'kind':'minimal frozen per-item receipt extract, not independent business validation','runs':frozen},ensure_ascii=False,indent=2)+'\n')
 (HERE/'receipt-sensitivity.json').write_text(json.dumps({'kind':'arithmetic derived from frozen per-question receipt; not independently rescored transactions','runs':rows},ensure_ascii=False,indent=2)+'\n')
 for r in rows:print(r['product'],r['replicate'],r['modes'])
 print('PASS: 8 receipt-derived sensitivities; original records unchanged')
if __name__=='__main__':main()
