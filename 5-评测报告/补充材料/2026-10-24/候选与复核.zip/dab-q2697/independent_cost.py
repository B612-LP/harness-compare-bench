#!/usr/bin/env python3
"""Raw-data DAB2697 fee sensitivity; imports no project/product code."""
import argparse
import csv
import datetime as dt
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re

ROOT=Path('/Users/b612-lp/Documents/harness-compare-bench')
HERE=Path(__file__).resolve().parent
INPUTS=ROOT/'2-用例/dabstep-payments-10/inputs'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def scale(s):
 s=s.strip().lower().replace('%','');return float(s.rstrip('km'))*(1000 if s.endswith('k') else 1_000_000 if s.endswith('m') else 1)
def interval(rule,value,percent=False):
 if rule is None:return True
 s=str(rule).strip()
 if percent:value*=100
 if s.startswith('>'):return value>scale(s[1:])
 if s.startswith('<'):return value<scale(s[1:])
 if '-' in s:
  a,b=s.split('-');return scale(a)<=value<=scale(b)
 return value==scale(s)
def capture(rule,value):
 if rule is None:return True
 if rule in ('manual','immediate'):return str(value)==rule
 try:return interval(rule,float(value))
 except ValueError:return False

def main():
 global INPUTS
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--inputs',type=Path,default=(HERE/'inputs' if (HERE/'inputs').is_dir() else INPUTS))
 ap.add_argument('--truth',type=Path,help='Optional frozen truth used only for post-computation reference')
 args=ap.parse_args();INPUTS=args.inputs.resolve(strict=True)
 assert interval('100k-1m',113260.42) and interval('>8.3%',0.1031306435,True)
 assert not interval('<7.2%',0.1031306435,True) and capture('<3','1') and not capture('3-5','1')
 assert capture('manual','manual') and not capture('immediate','1')
 files=[INPUTS/n for n in ('manual.md','fees.json','payments.csv','merchant_data.json','questions.jsonl')]
 before={str(p):digest(p) for p in files}
 fees=json.loads((INPUTS/'fees.json').read_text());merchant=next(m for m in json.loads((INPUTS/'merchant_data.json').read_text()) if m['merchant']=='Belles_cookbook_store')
 rows=[];year_months=Counter()
 with (INPUTS/'payments.csv').open() as f:
  for row in csv.DictReader(f):
   if row['merchant']!=merchant['merchant']:continue
   date=dt.date(int(row['year']),1,1)+dt.timedelta(days=int(row['day_of_year'])-1)
   year_months[str(date)[:7]]+=1
   if date.year!=2023 or date.month!=1:continue
   row['amount']=float(row['eur_amount']); row['fraud']=row['has_fraudulent_dispute']=='True'; row['refused']=row['is_refused_by_adyen']=='True'; row['credit']=row['is_credit']=='True'
   row['month']=str(date)[:7];rows.append(row)
 def metrics(group,kind):
  volume=sum(r['amount'] for r in group);fraudvol=sum(r['amount'] for r in group if r['fraud'])
  rate=fraudvol/volume if kind=='volume' else sum(r['fraud'] for r in group)/len(group)
  return {'volume':volume,'fraud_volume':fraudvol,'fraud_rate':rate,'count':len(group),'fraud_count':sum(r['fraud'] for r in group)}
 def belongs(rule,v,empty):return rule is None or (isinstance(rule,list) and (v in rule or (not rule and empty))) or (not isinstance(rule,list) and rule==v)
 all_targets=[r for r in rows if r['fraud']]
 out={'method':'declared-assumption raw-data constraint matching, no product/checker imported','merchant':merchant,'merchant_month_counts':dict(year_months),'january_metrics':metrics(rows,'volume'),'target_fraud_count':len(all_targets),'target_refused_count':sum(r['refused'] for r in all_targets),'fee_field_values':{k:sorted({json.dumps(f[k],sort_keys=True) for f in fees}) for k in ('capture_delay','monthly_fraud_level','monthly_volume')},'scenarios':[]}
 settings=[('primary_min_all',True,'volume',False,False),('exclude_refused',True,'volume',True,False),('fraud_count_ratio',True,'count',False,False),('metrics_by_scheme',True,'volume',False,True),('literal_empty_lists',False,'volume',False,False)]
 for label,empty,kind,refused,by_scheme in settings:
  base=[r for r in rows if not(refused and r['refused'])];targets=[r for r in base if r['fraud']]
  groups=defaultdict(list)
  for row in base:groups[(row['month'],row['card_scheme'] if by_scheme else None)].append(row)
  met={k:metrics(v,kind) for k,v in groups.items()}
  eligible={}
  for key,m in met.items():
   eligible[key]=[f for f in fees if belongs(f['account_type'],merchant['account_type'],empty) and belongs(f['merchant_category_code'],merchant['merchant_category_code'],empty) and capture(f['capture_delay'],merchant['capture_delay']) and interval(f['monthly_volume'],m['volume']) and interval(f['monthly_fraud_level'],m['fraud_rate'],True)]
  scenario={'name':label,'target_count':len(targets),'metrics':{str(k):v for k,v in met.items()},'candidate_aci':[]}
  for aci in 'ABCDEFG':
   totals={'min':0.,'mean':0.,'max':0.,'sum':0.};coverage=0;counts=Counter();iduse=Counter();missing=Counter();samples=[]
   for row in targets:
    key=(row['month'],row['card_scheme'] if by_scheme else None)
    matched=[f for f in eligible[key] if f['card_scheme']==row['card_scheme'] and belongs(f['aci'],aci,empty) and belongs(f['is_credit'],row['credit'],empty) and belongs(f['intracountry'],row['issuing_country']==row['acquirer_country'],empty)]
    counts[len(matched)]+=1
    if not matched:missing[row['card_scheme']]+=1;continue
    coverage+=1
    prices=[(float(f['fixed_amount'])+float(f['rate'])*row['amount']/10000,f['ID']) for f in matched]
    for cost,id_ in prices:iduse[id_]+=1
    values=[v for v,id_ in prices]
    totals['min']+=min(values);totals['mean']+=sum(values)/len(values);totals['max']+=max(values);totals['sum']+=sum(values)
    if len(samples)<3:samples.append({'amount':row['amount'],'scheme':row['card_scheme'],'credit':row['credit'],'domestic':row['issuing_country']==row['acquirer_country'],'prices':sorted(prices)})
   scenario['candidate_aci'].append({'aci':aci,'covered':coverage,'missing':len(targets)-coverage,'match_multiplicity':dict(counts),'missing_by_scheme':dict(missing),'full_cost':totals if coverage==len(targets) else None,'covered_only_cost_NOT_full_cost':totals,'fee_ids':sorted(iduse),'sample_matches':samples})
  for agg in ('min','mean','max','sum'):
   complete=[c for c in scenario['candidate_aci'] if c['full_cost'] is not None]
   scenario['winner_'+agg]=min(complete,key=lambda c:c['full_cost'][agg])['aci'] if complete else None
  out['scenarios'].append(scenario)
 # Read gold only after all scenarios computed; never used in matching or parameter choice.
 out['official_gold_reference']=json.loads(args.truth.read_text())['gold']['2697'] if args.truth else 'E:13.57 (previously read frozen reference, not used in computation)'
 out['read_only_hash_checks']={str(p):digest(p)==h for p,h in ((Path(k),v) for k,v in before.items())}
 assert all(out['read_only_hash_checks'].values())
 (HERE/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print('January',out['january_metrics'],'target fraud',len(all_targets),'refused',out['target_refused_count'])
 for s in out['scenarios']:
  print('\nSCENARIO',s['name'])
  for c in s['candidate_aci']:print(c['aci'],'coverage',c['covered'],'/',s['target_count'],'cost',c['full_cost'],'partial',c['covered_only_cost_NOT_full_cost'] if c['full_cost'] is None else '', 'multiplicity',c['match_multiplicity'])
  print('winners',{k:v for k,v in s.items() if k.startswith('winner_')})
 print('Post-compute gold reference',out['official_gold_reference'],'hashes all unchanged')

if __name__=='__main__':main()
