#!/usr/bin/env python3
"""Independent aggregate check, not a replacement gold or product run.
No agent implementation imports. No personal transaction fields exported.
"""
import argparse
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
D = Decimal


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--inputs', type=Path, default=HERE / 'dab-q2697/inputs')
    args = ap.parse_args()
    base = args.inputs.resolve()
    files = ['fees.json', 'merchant_data.json', 'payments.csv', 'questions.jsonl', 'manual.md']
    before = {f: hashlib.sha256((base / f).read_bytes()).hexdigest() for f in files}
    merchant = next(x for x in json.loads((base/'merchant_data.json').read_text()) if x['merchant']=='Belles_cookbook_store')
    rules = json.loads((base/'fees.json').read_text())
    with (base/'payments.csv').open(newline='') as handle:
        january = [x for x in csv.DictReader(handle) if x['merchant']==merchant['merchant'] and x['year']=='2023' and 1<=int(x['day_of_year'])<=31]
    fraud = [x for x in january if x['has_fraudulent_dispute']=='True']
    total = sum((D(x['eur_amount']) for x in january), D(0))
    ftotal = sum((D(x['eur_amount']) for x in fraud), D(0))
    assert D(100000) < total < D(1000000) and ftotal/total > D('.083')
    def member(value, spec, empty_all):
        if spec is None: return True
        if isinstance(spec, list): return (empty_all and not spec) or value in spec
        return value == spec
    output = {'scope':'Independent declared-assumption sensitivity, not a new gold',
              'january':{'transactions':len(january),'volume_eur':str(total),'fraud_transactions':len(fraud),'fraud_volume_eur':str(ftotal),'fraud_ratio':str(ftotal/total)},
              'fraud_observed_aci_counts':dict(Counter(x['aci'] for x in fraud)), 'variants':{}, 'inputs_sha256':before}
    for empty_all in (False, True):
        eligible = [r for r in rules if member(merchant['account_type'],r['account_type'],empty_all)
                    and member(merchant['merchant_category_code'],r['merchant_category_code'],empty_all)
                    and r['capture_delay'] in (None,'<3') and r['monthly_volume'] in (None,'100k-1m')
                    and r['monthly_fraud_level'] in (None,'>8.3%')]
        costs = {}
        for aci in 'ABCDEFG':
            by_mode = {k:D(0) for k in ('sum_all_matches','mean_per_matched_transaction','min_per_matched_transaction','max_per_matched_transaction')}
            matched = 0
            for tx in fraud:
                values = [D(str(r['fixed_amount']))+D(r['rate'])*D(tx['eur_amount'])/D(10000)
                          for r in eligible if r['card_scheme']==tx['card_scheme']
                          and member(tx['is_credit']=='True',r['is_credit'],empty_all)
                          and member(aci,r['aci'],empty_all)
                          and member(tx['issuing_country']==tx['acquirer_country'],r['intracountry'],empty_all)]
                if not values: continue
                matched += 1
                by_mode['sum_all_matches'] += sum(values)
                by_mode['mean_per_matched_transaction'] += sum(values)/len(values)
                by_mode['min_per_matched_transaction'] += min(values)
                by_mode['max_per_matched_transaction'] += max(values)
            costs[aci] = {'matched_transactions':matched,'unmatched_transactions':len(fraud)-matched,
                          'costs_eur':{k:str(v) for k,v in by_mode.items()}}
        output['variants']['empty_list_wildcard' if empty_all else 'null_only_wildcard'] = costs
    after = {f: hashlib.sha256((base/f).read_bytes()).hexdigest() for f in files}
    assert before == after
    output['inputs_unchanged'] = True
    (HERE/'lead-dab-probe.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'january':output['january'],'empty_wildcard_E':output['variants']['empty_list_wildcard']['E'],'null_only_E':output['variants']['null_only_wildcard']['E']},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
