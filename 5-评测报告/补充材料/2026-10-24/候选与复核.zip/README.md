# 2026-10-24 追加交付：q26修正版与DAB q2697独立复核

## 结果先看

**BIRD q26已修成可运行的独立候选版本；DAB q2697已查到具体口径缺口，但不能诚实宣布唯一业务答案已确定。** 两项均无新增受评产品模型/GUI运行，无联网调用，不触碰仓外G2R4。

交付位于仓外，状态为 **candidate-not-adopted**。原仓仍是 `a2234fccad1a437ae83b2989d2769d8881f81ba5`；原始现场、旧gold、原分、现有报告、CHANGELOG均未改，邮件未发送。本包不是对已提交版本的静默替换。

## 1. q26：从已知问题推进到修复与验收

- [独立候选说明](<bird-q26/README.md>)；[完整候选合同](<bird-q26/candidate-1.2-q26-frpm/spec.md>)；[可运行checker](<bird-q26/candidate-1.2-q26-frpm/checker.py>)。
- 版本为 **1.2-q26-frpm**：仅q26将Free Meal改为FRPM，明确本地5–17岁与严格大于800；数据库及其他14题gold不变。原英文15–17保留为来源差异，q27人口/NULL/键格式争议未擅自改写。
- 旧自测 **21/21**、候选自测 **25/25**；新旧oracle交叉 **3/3**，另有799/800/801合成边界。单题错误只丢该题，未错误添加整场硬否决。
- Lead另用独立基础行重构确认6所学校，并验证12/15通过、将q26换回旧Free后11/15不通过。

| 历史答案 | 旧1.1参考 | 候选合同回放 | 二值变化 |
|---|---:|---:|---|
| Codex、DSH、WorkBuddy首跑 | 86.67 | 93.33 | 均1→1 |
| 豆包首跑 | 60.00 | 66.67 | 0→0 |
| Codex r3 | 80.00 | 86.67 | 1→1 |
| 其余三个CLI重复 | 86.67 | 93.33 | 均1→1 |

八场均只增加q26一题。原答案不改，临时运行目录使用对应版本输入，输入门全部核验；这是**旧答案对新合同的迁移回放**，不是模型在新题面下重新取得的成绩，不表示能力提升。完整命令和逐项收据见[构建/回放程序](<bird-q26/build_replay.py>)及[审计结果](<bird-q26/audit.json>)。

## 2. DAB q2697：不能拿不完整费用证明“最优”

[完整有界结论](<dab-q2697/README.md>)与[独立业务计算](<dab-q2697/independent_cost.py>)给出原始交易、费率、手册的对应关系。另一套[Lead Decimal计算](<lead_dab_probe.py>)未导入作者算法，独立交叉核对。

- 真正冻结gold是 **E:13.57**；**E:41.66是Codex历史预测，不是gold**。
- 1月1201笔交易，欺诈94笔；改为E后只有 **44/94** 笔匹配费率，另50笔未定价。41.66可由已覆盖部分的平均匹配费复现，但不能当完整94笔总费，不能默默把缺匹配当免费。
- A/B/C可完整覆盖；每笔取最低费或平均费时B较小，逐笔相加所有匹配费或取最高费时C较小。手册没有唯一规定多规则聚合/优先级，最优ACI随口径变化。
- 题面要求ACI，却给`{card_scheme}:{fee}`格式，仍有输出字段冲突。所测口径未支持E:13.57，不等于已证明上游gold必错；**不制造替代金标**。
- 处置：保留冻结金标兼容分，但不把该题失配直接作业务能力扣分；后续必须先明确聚合、未匹配交易和输出字段政策。
- 从既有逐题receipt派生的剔除2697敏感性：八场official/strict二值均不变。[派生结果](<dab-q2697/receipt-sensitivity.json>)不是新增独立判卷，也不证明其余9题语义正确。

## 3. 复跑与边界

解压后从本包根目录执行，以下仅需Python标准库及本包输入，无需原机器路径或网络：

```bash
python3 -B bird-q26/candidate-1.2-q26-frpm/checker.py --selftest
python3 -B dab-q2697/independent_cost.py --truth dab-q2697/frozen-truth.json
python3 -B dab-q2697/receipt_sensitivity.py --results dab-q2697/receipt-source.json
python3 -B lead_dab_probe.py
```

若要重新核对原仓全部文件、构建候选和重放八份历史答案，需准备原仓a2234fc版本，再显式传入路径：

```bash
python3 -B bird-q26/build_replay.py --repo /path/to/harness-compare-bench
python3 -B lead_acceptance.py --repo /path/to/harness-compare-bench --candidate bird-q26/candidate-1.2-q26-frpm
```

[Lead独立验收收据](<lead-acceptance.json>)记录候选语义、正反例、跨算法费用核对及原仓1323个已跟踪文件逐字节未变。checker仍为既有只读SQL结果集比较框架，不宣称任意敌意程序安全隔离、题库一般正确性或纯Harness因果排名。

数据许可：BIRD数据库与题源为CC BY-SA 4.0，详见[候选来源](<bird-q26/candidate-1.2-q26-frpm/spec.md>)；DABstep公开输入为CC BY 4.0，来源与许可证在[冻结来源记录](<dab-q2697/frozen-truth.json>)。交易数据为原公开评测输入；报告仅输出聚合和规则，不导出个人字段作为新证据。
