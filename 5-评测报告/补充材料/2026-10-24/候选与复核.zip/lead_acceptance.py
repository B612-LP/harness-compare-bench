#!/usr/bin/env python3
"""Independent acceptance for external q26 candidate and q2697 audit.
Uses the original repository read-only. Creates temporary BIRD submissions only.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
CHECKS = []


def load(p):
    return json.loads(p.read_text(encoding='utf-8'))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check(name, value):
    CHECKS.append({'test':name,'pass':bool(value)})
    print(('PASS ' if value else 'FAIL ')+name, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--candidate', type=Path, required=True)
    args = ap.parse_args()
    repo, candidate = args.repo.resolve(), args.candidate.resolve()
    old = repo/'2-用例/bird-ca-schools-15'
    ot, nt = load(old/'truth.json'), load(candidate/'truth.json')
    changed = {q for q in ot['answers'] if ot['answers'][q] != nt['answers'][q]}
    check('only_q26_gold_changed', changed == {'26'})
    check('gold_frpm_and_versions_explicit', 'FRPM Count (Ages 5-17)' in nt['answers']['26']['sql']
          and nt['checker_version'] != ot['checker_version'])
    oq, nq = load(old/'inputs/questions.json'), load(candidate/'inputs/questions.json')
    changed_q = {x['question_id'] for x,y in zip(oq,nq) if x != y}
    check('only_q26_input_question_changed', len(oq)==len(nq)==15 and changed_q == {26})
    check('original_data_schema_samples_unchanged', all(sha(old/p)==sha(candidate/p) for p in (
          'inputs/db/california_schools.sqlite','inputs/schema.sql','inputs/sample_rows.json')))
    check('new_canonical_input_hashes_match', all(sha(candidate/p)==digest for p,digest in nt['input_sha256'].items()))
    con = sqlite3.connect((candidate/'inputs/db/california_schools.sqlite').as_uri()+'?mode=ro&immutable=1',uri=True)
    con.execute('PRAGMA query_only=ON')
    # Reconstruct q26 from source rows without using either gold query.
    schools = {r[0]:r[1:] for r in con.execute('SELECT CDSCode,County,Street,City,State,Zip FROM schools')}
    independently_expected=[]
    for code,name,typ,count in con.execute('SELECT CDSCode,`School Name`,`School Type`,`FRPM Count (Ages 5-17)` FROM frpm'):
        s=schools.get(code)
        if s and s[0]=='Monterey' and typ=='High Schools (Public)' and count is not None and count>800:
            independently_expected.append((name,*s[1:]))
    actual=con.execute(nt['answers']['26']['sql']).fetchall()
    check('new_gold_matches_independent_six_schools', len(actual)==6 and Counter(actual)==Counter(independently_expected))
    con.close()
    def judge(pairs):
        with tempfile.TemporaryDirectory(prefix='q26-lead-fixture-') as td:
            run=Path(td)
            (run/'answers.jsonl').write_text(''.join(json.dumps({'question_id':int(q),'sql':s})+'\n' for q,s in pairs.items()))
            p=subprocess.run([sys.executable,'-B',str(candidate/'checker.py'),str(run),'--json'],capture_output=True,text=True,timeout=180)
            result=json.loads(p.stdout.strip().splitlines()[-1])
            return p.returncode,result
    new_pairs={q:v['sql'] for q,v in nt['answers'].items()}
    rc,new=judge(new_pairs)
    check('new_oracle_15_of_15', rc==0 and new['correct']==15 and new['reward']==1)
    old_pairs={q:v['sql'] for q,v in ot['answers'].items()}
    rc,legacy=judge(old_pairs)
    check('old_free_only_gold_rejected_per_question', legacy['correct']==14 and legacy['failed_questions']==['26']
          and legacy['weighted']==93.33 and legacy['reward']==1)
    near=dict(new_pairs)
    for q in ('28','36','62'): near[q]='SELECT 1 WHERE 0'
    rc,positive=judge(near)
    check('threshold_12_of_15_frpm_passes',rc==0 and positive['correct']==12 and positive['reward']==1)
    near['26']=ot['answers']['26']['sql']
    rc,negative=judge(near)
    check('threshold_11_of_15_free_only_fails',rc==1 and negative['correct']==11 and negative['reward']==0)
    p=subprocess.run([sys.executable,'-B',str(candidate/'checker.py'),'--selftest'],capture_output=True,text=True,timeout=600)
    check('candidate_selftest',p.returncode==0)
    (HERE/'lead-candidate-selftest.log').write_text(p.stdout+p.stderr)
    probe=load(HERE/'lead-dab-probe.json')
    e=probe['variants']['empty_list_wildcard']['E']
    check('independent_dab_94_fraud_transactions',probe['january']['fraud_transactions']==94)
    check('E_partial_coverage_not_total_fee',e['matched_transactions']==44 and e['unmatched_transactions']==50)
    check('codex_41_66_explained_not_gold_proven',round(float(e['costs_eur']['mean_per_matched_transaction']),2)==41.66)
    independent=load(HERE/'dab-q2697/results.json')
    primary=next(s for s in independent['scenarios'] if s['name']=='primary_min_all')
    rows={x['aci']:x for x in primary['candidate_aci']}
    modes={'sum_all_matches':'sum','mean_per_matched_transaction':'mean','min_per_matched_transaction':'min','max_per_matched_transaction':'max'}
    agree=True
    for aci, ours in probe['variants']['empty_list_wildcard'].items():
        other=rows[aci]
        agree &= ours['matched_transactions']==other['covered'] and ours['unmatched_transactions']==other['missing']
        agree &= all(abs(float(ours['costs_eur'][k])-other['covered_only_cost_NOT_full_cost'][v])<1e-7 for k,v in modes.items())
    check('two_independent_DAB_methods_agree_7_ACI_4_aggregates',agree)
    check('DAB_missing_coverage_not_reported_as_full_cost',rows['E']['full_cost'] is None)
    check('DAB_packaged_inputs_and_frozen_gold_unchanged',sha(HERE/'dab-q2697/frozen-truth.json')==sha(repo/'2-用例/dabstep-payments-10/truth.json')
          and all(sha(HERE/'dab-q2697/inputs'/p)==digest for p,digest in load(HERE/'dab-q2697/frozen-truth.json')['input_sha256'].items()))
    baseline=load(HERE/'repository-before.json')
    check('all_original_tracked_bytes_unchanged',all(sha(repo/p)==digest for p,digest in baseline['files'].items()))
    status=subprocess.check_output(['git','status','--porcelain'],cwd=repo).decode()
    check('original_repository_clean',not status)
    out={'kind':'lead-independent-contract-fix-acceptance','passed':sum(x['pass'] for x in CHECKS),
         'total':len(CHECKS),'checks':CHECKS,'new_product_runs':0,'original_commit':baseline['commit']}
    (HERE/'lead-acceptance.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':out['passed'],'total':out['total']}))
    return 0 if out['passed']==out['total'] else 1


if __name__=='__main__':
    raise SystemExit(main())
